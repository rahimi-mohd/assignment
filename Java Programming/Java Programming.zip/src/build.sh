#!/usr/bin/sh

javac -d ../bin/ *.java

java -classpath ../bin/ Main